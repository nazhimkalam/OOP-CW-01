// interface for the date
export interface Date {

  // variables 
  day: number;
  month: number;
  year: number;

}
